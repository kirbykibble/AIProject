﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class controller : MonoBehaviour
{

    public TextMesh curAction;
    public TextMesh timer;
    public TextMesh yourWins;
    public TextMesh theirWins;

    public Sprite shoot;
    public Sprite reload;
    public Sprite guard;
    public GameObject playerSpriteObj;
    public GameObject enemySpriteObj;
    public GameObject playerBullet;
    public GameObject enemyBullet;

    private int curTime;
    private int playerWins;
    private int enemyWins;

    private bool playerLoaded;
    private bool opponentLoaded;

    private int curPlayerAction; //0 = no action chosen. 1 = reload. 2 = guard. 3 = shoot
    private int curEnemyAction; //0 = no action chosen. 1 = reload. 2 = guard. 3 = shoot

    private bool roundIsRunning;
       
    private SpriteRenderer pSprite;
    private SpriteRenderer oSprite;

    private bool gameEnded;

    Dictionary<string, List<int>> decagram = new Dictionary<string, List<int>>();
    List<int> playerActions = new List<int>();

    // Start is called before the first frame update
    void Start()
    {
        curTime = 3;
        playerWins = 0;
        enemyWins = 0;
        playerLoaded = true;
        opponentLoaded = true;
        roundIsRunning = false;
        gameEnded = false;

        pSprite = playerSpriteObj.GetComponent<SpriteRenderer>();
        oSprite = enemySpriteObj.GetComponent<SpriteRenderer>();

        pSprite.sprite = null;
        oSprite.sprite = null;
    }

    // Update is called once per frame
    void Update()
    {
        if(playerLoaded)
        {
            playerBullet.SetActive(true);
        }
        else
        {
            playerBullet.SetActive(false);
        }

        if (opponentLoaded)
        {
            enemyBullet.SetActive(true);
        }
        else
        {
            enemyBullet.SetActive(false);
        }

        if(Input.GetKeyDown(KeyCode.R))
        {
            curPlayerAction = 1;
            curAction.text = "Your Next Action: \nReload";
        }
        if(Input.GetKeyDown(KeyCode.Space))
        {
            curPlayerAction = 2;
            curAction.text = "Your Next Action: \nGuard";
        }
        if(Input.GetMouseButtonDown(0))
        {
            curPlayerAction = 3;
            curAction.text = "Your Next Action: \nShoot";
        }

        yourWins.text = "Your wins: " + playerWins;
        theirWins.text = "Their wins: " + enemyWins;

        if(gameEnded)
        {
            curAction.text = "game ended. \nSpace to play again";
            StopAllCoroutines();
        }
        
        if(gameEnded && Input.GetKeyDown(KeyCode.Space)) 
        {
            resetGame();
        }

        if(!roundIsRunning && !gameEnded)
        {
            StartCoroutine(gameTimer());
        }
    }

    void compareActions()
    {
        //updates sprites
        if(curPlayerAction == 1)
        {
            pSprite.sprite = reload;
        }
        if(curPlayerAction == 2)
        {
            pSprite.sprite = guard;
        }
        if(curPlayerAction == 3)
        {
            pSprite.sprite = shoot;
        }
        if (curEnemyAction == 1)
        {
            oSprite.sprite = reload;
        }
        if(curEnemyAction == 2)
        {
            oSprite.sprite = guard;
        }
        if(curEnemyAction == 3)
        {
            oSprite.sprite = shoot;
        }

        if(curPlayerAction == 0)
        {
            enemyWins++;
            gameEnded = true;
        }


        if(curEnemyAction == curPlayerAction) //both do same thing
        {
            if (curPlayerAction == 1)
            {
                playerLoaded = true;
                opponentLoaded = true;

            }
            else if (curPlayerAction == 2)
            {
                //both guarded.. does nothing
            }
            else if (curPlayerAction == 3) //bot tried to shoot
            {
                if (playerLoaded == opponentLoaded) //both shot with same ammo status
                {
                    playerLoaded = false;
                    opponentLoaded = false;
                }
                else if (playerLoaded) //only the player is loaded
                {
                    //player wins
                    playerWins++;
                    gameEnded = true;
                }
                else if (opponentLoaded) // only the opponent is loaded
                {
                    //opponent wins
                    enemyWins++;
                    gameEnded = true;
                }
            }
        }
        else
        {
            if(curPlayerAction == 3 && curEnemyAction != 2) //if player shoots and enemy doesn't guard
            {
                if (playerLoaded)
                {
                    //player wins
                    playerWins++;
                    gameEnded = true;
                }
                else
                {
                    //nothing happens
                }
            }
            else if(curPlayerAction == 3 && curEnemyAction == 2)
            {
                playerLoaded = false;
            }
            if(curEnemyAction == 3 && curPlayerAction != 2)
            {
                if (opponentLoaded)
                {
                    //enemy wins
                    enemyWins++;
                    gameEnded = true;
                }
                else
                {
                    //nothing happens
                }
            }
            else if (curEnemyAction == 3 && curPlayerAction == 2)
            {
                opponentLoaded = false;
            }

            if(curPlayerAction == 1) //reloading
            {
                playerLoaded = true;
            }
            if(curEnemyAction == 1)
            {
                opponentLoaded = true;
            }
        }
    }

    void enemyDecision()
    {
        decagram = new Dictionary<string, List<int>>();
        print("PLAYER ACTIONS: " + playerActions.Count);
        if (playerActions.Count <= 3)
        {
            curEnemyAction = Random.Range(1, 4);
            //print("ENEMY DECISION: " + curEnemyAction.ToString());
            if (curEnemyAction == 3 && !opponentLoaded)
            {
                curEnemyAction = 1;
            }
        }
        else
        {
            for(int i = 5; i < playerActions.Count; i++)
            {
                string bigram = playerActions[i - 2].ToString() + playerActions[i - 1].ToString(); //YES I KNOW THIS IS A MESS 
                print(bigram);

                if(!decagram.ContainsKey(bigram))
                {
                    List<int> temp = new List<int>();
                    temp.Add(playerActions[i]);
                    decagram.Add(bigram, temp);
                }
                else
                {
                    decagram[bigram].Add(playerActions[i]);
                }
            }

            //gets last 10 entries
            string bigram2 = playerActions[playerActions.Count - 2].ToString() + playerActions[playerActions.Count - 1].ToString(); //YES I KNOW THIS IS A MESS 

            foreach (KeyValuePair<string, List<int>> entry in decagram)
            {
                if(bigram2 == entry.Key)
                {
                    float reloadLike = 0.0f;
                    float guardLike = 0.0f;
                    float shootLike = 0.0f;

                    int rCount = 0;
                    int gCount = 0;
                    int sCount = 0;

                    for(int i = 0; i < entry.Value.Count; i++)
                    {
                        if(entry.Value[i] == 1)
                        {
                            rCount++;
                        }else if(entry.Value[i] == 2)
                        {
                            gCount++;
                        }else if(entry.Value[i] == 3)
                        {
                            sCount++;
                        }
                    }

                    reloadLike = (float)rCount / (float)entry.Value.Count;
                    guardLike = (float)gCount / (float)entry.Value.Count;
                    shootLike = (float)sCount / (float)entry.Value.Count;

                    print(reloadLike + ": RELOAD LIKE");
                    print(guardLike + ": GUARD LIKE");
                    print(shootLike + ": SHOOT LIKE");

                    if(reloadLike > guardLike && reloadLike > shootLike)
                    {
                        //if player reload is most likely course of action, then shoot or reload if possible. 
                        if(opponentLoaded)
                        {
                            curEnemyAction = 3;
                        }
                        else
                        {
                            curEnemyAction = 1;
                        }
                    }
                    if(guardLike > reloadLike && guardLike > shootLike)
                    {
                        //if player guard is most likely course of action, just reload. 
                        curEnemyAction = 1;
                    }
                    if(shootLike > reloadLike && shootLike > guardLike)
                    {
                        //if player is likely to shoot, then guard.
                        if (!playerBullet)
                        {
                            curEnemyAction = 3;
                        }
                        else
                        {
                            curEnemyAction = 2;
                        }
                    }



                }
            } 
        }
    }

    void resetGame()
    {
        playerLoaded = true;
        opponentLoaded = true;
        pSprite.sprite = null;
        oSprite.sprite = null;
        StopAllCoroutines();
        gameEnded = false;

    }

    IEnumerator gameTimer()
    {
        roundIsRunning = true;

        curEnemyAction = 2;
        //run enemy decision
        enemyDecision();

        curPlayerAction = 0;
        curAction.text = "No Action selected!";

        while (curTime > 0)
        {
            curTime -= 1;
            timer.text = curTime.ToString();
            yield return new WaitForSeconds(0.5f);
        }
        playerActions.Add(curPlayerAction);
        compareActions(); 

        curTime = 4;
        roundIsRunning = false;        
    }
}
