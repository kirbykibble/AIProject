﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SiloController : MonoBehaviour
{
    //******************************
    // Rule Based System
    //******************************

    public GameObject silo;
    public GameObject Ryder;
    public GameObject missile;
    public AudioSource AUS;
    public AudioClip ohno;
    public AudioClip siren;
    public int distanceToActivate = 500;
    public int missiles = 2;

    private bool firing = false;
    private bool ohnod = false;
    public float diffToFire = 10.0f;

    // Start is called before the first frame update
    void Start()
    {
        Ryder = GameObject.Find("Ryder");
        AUS = this.GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Vector3.Distance(this.transform.position, Ryder.transform.position) <= distanceToActivate && firing == false)
        {
            if(!firing)
            {
                StartCoroutine(decisionTree());
            }
        }
    }
    IEnumerator decisionTree()
    {
        firing = true;
        if (missiles > 0)
        {
            missiles--;
            GameObject newMissile = Instantiate(missile);
            newMissile.transform.position = new Vector3(silo.transform.position.x, silo.transform.position.y, silo.transform.position.z);

        }
        else if (missiles <= 0) 
        {
            yield return new WaitForSeconds(10.0f);
            missiles = 2;
        }
        else
        {
            print("nothing interesting");
        }

        yield return new WaitForSeconds(diffToFire);
        firing = false;
    }
}
