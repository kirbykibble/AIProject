﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CannonController : MonoBehaviour
{
    //******************************
    // Finite State Machine
    //******************************
    public GameObject cannon;
    public GameObject Ryder;
    public float strength = 10.0f;
    public GameObject cannonBall;
    public float cannonStr = 10.0f;

    public int distanceToActivate = 200;
    public int state; //0 = look for enemy; 1 = Rotate towards enemy; 2 = Shoot at enemy
    private int stateBuffer;
    private bool firing = false;
    // Start is called before the first frame update
    void Start()
    {
        Ryder = GameObject.Find("Ryder");
        state = 0;
        stateBuffer = 0;
    }

    // Update is called once per frame
    void Update()
    {
        checkState(state);
    }

    void checkState(int state)
    {
        //updates the state
        //checks to see if player is within range
        if (Vector3.Distance(this.transform.position, Ryder.transform.position) <= distanceToActivate)
        {

            //if so, check to see if player is in front of the cannon
            Vector3 dirFrom = (Ryder.transform.position - this.transform.position).normalized;
            float dotProd = Vector3.Dot(dirFrom, this.transform.forward);
            if (dotProd > 0.99)
            {
                //if so, fire at player
                state = 2;
            }
            else
            {
                //else, rotate to the player
                state = 1;
                stateBuffer = state;
            }

        }
        else
        {
            //if player isn't within range, patrol
            state = 0;
            if (stateBuffer == 1)
            {
                this.transform.eulerAngles = new Vector3(0, 0, 0);
            }
            stateBuffer = state;
        }

        //switch statement
        switch (state)
        {
            case 0:
                patrol();
                break;
            case 1:
                rotate();
                break;
            case 2:
                rotate();
                if (firing == false)
                {
                    StartCoroutine(shoot());
                }
                break;
        }
    }

    void patrol()
    {
        this.transform.Rotate(new Vector3(0,1, 0));
    }
    void rotate()
    {
        Quaternion targetRotation = Quaternion.LookRotation(Ryder.transform.position - this.transform.position);
        float str = Mathf.Min(strength * Time.deltaTime, 1);
        this.transform.rotation = Quaternion.Lerp(transform.rotation, targetRotation, str);
    }
    IEnumerator shoot()
    {
        firing = true;
        GameObject newBall = Instantiate(cannonBall);
        newBall.transform.position = new Vector3(this.transform.position.x, this.transform.position.y + 8, this.transform.position.z);
        Rigidbody ballRb = newBall.GetComponent<Rigidbody>();
        ballRb.AddForce(this.transform.forward * cannonStr);
        yield return new WaitForSeconds(0.5f);
        firing = false;

    }
}
