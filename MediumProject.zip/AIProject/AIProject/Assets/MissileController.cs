﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MissileController : MonoBehaviour
{
    private float speed = 100;
    private float rotationSpeed = 1;
    private float focusDistance = 5;
    public GameObject Ryder;
    public Transform RyderTransform;
    private bool isLookingAtObject = true;
    public GameObject missile;
    public GameObject explosions;

    private void Start()
    {
        Ryder = GameObject.Find("Ryder");
        RyderTransform = Ryder.transform;
    }

    private void Update()
    {
        Vector3 targetDirection = RyderTransform.position - transform.position;
        Vector3 newDirection = Vector3.RotateTowards(transform.forward, targetDirection, rotationSpeed * Time.deltaTime, 0.0f);
        transform.Translate(Vector3.forward * Time.deltaTime * speed, Space.Self);
        if (Vector3.Distance(transform.position, RyderTransform.position) < focusDistance)
        {
            isLookingAtObject = false;
        }
        if (isLookingAtObject)
        {
            transform.rotation = Quaternion.LookRotation(newDirection);
        }

        if (Vector3.Distance(this.transform.position, Ryder.transform.position) <= 5)
        {
            GameObject newBoom = Instantiate(explosions);
            newBoom.transform.position = this.transform.position;
            Destroy(gameObject);
        }
    }
}
