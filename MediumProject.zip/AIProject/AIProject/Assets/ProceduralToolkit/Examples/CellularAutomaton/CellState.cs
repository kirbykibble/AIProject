﻿namespace ProceduralToolkit.Examples
{
    public enum CellState
    {
        Dead = 0,
        Alive = 1
    }
}