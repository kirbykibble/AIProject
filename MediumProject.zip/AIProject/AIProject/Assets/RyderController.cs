﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RyderController : MonoBehaviour
{

    public GameObject Ryder;
    private Rigidbody ryderPhys;
    public float uSpeed = 1.0f;
    private bool isOnGround = false;
    public bool gliderDeployed = true;
    public bool rocketDeployed = false;
    public bool touchingGround = false;
    private bool forcedClosed = false;

    public float speed = 1.0f;
    public float rocketSpeed = 200.0f;
    public float pitchPower = 500;
    public float yawPower = 500;
    public float rollPower = 500;

    public GameObject wingL;
    public GameObject wingR;
    public GameObject rearL;
    public GameObject rearR;
    public GameObject tailFin;
    public GameObject glider;
    public GameObject rocketL;
    public GameObject rocketR;

    // Start is called before the first frame update
    void Start()
    {
        ryderPhys = Ryder.GetComponent<Rigidbody>();
    }

    public void forceClose()
    {
        forcedClosed = true;
        gliderDeployed = false;
        wingL.GetComponent<plateMesh>().enabled = false;
        wingR.GetComponent<plateMesh>().enabled = false;
        rearL.GetComponent<plateMesh>().enabled = false;
        rearR.GetComponent<plateMesh>().enabled = false;
        tailFin.GetComponent<plateMesh>().enabled = false;

        wingL.SetActive(false);
        wingR.SetActive(false);
        rearL.SetActive(false);
        rearR.SetActive(false);
        tailFin.SetActive(false);

        glider.SetActive(false);
        rocketL.SetActive(false);
        rocketR.SetActive(false);
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (Input.GetKeyDown(KeyCode.Space) && !forcedClosed)
        {
            gliderDeployed = !gliderDeployed;
            if (gliderDeployed == false)
            {
                wingL.GetComponent<plateMesh>().enabled = false;
                wingR.GetComponent<plateMesh>().enabled = false;
                rearL.GetComponent<plateMesh>().enabled = false;
                rearR.GetComponent<plateMesh>().enabled = false;
                tailFin.GetComponent<plateMesh>().enabled = false;

                glider.SetActive(false);
                rocketL.SetActive(false);
                rocketR.SetActive(false);
            }
            else if (gliderDeployed == true)
            {
                wingL.GetComponent<plateMesh>().enabled = true;
                wingR.GetComponent<plateMesh>().enabled = true;
                rearL.GetComponent<plateMesh>().enabled = true;
                rearR.GetComponent<plateMesh>().enabled = true;
                tailFin.GetComponent<plateMesh>().enabled = true;

                glider.SetActive(true);
                rocketR.SetActive(true);
                rocketL.SetActive(true);
            }
        }
        if (Input.GetKey(KeyCode.W) && gliderDeployed)
        {
            ryderPhys.AddRelativeForce(transform.right * rocketSpeed);
        }
        if (Input.GetKey(KeyCode.A) && !gliderDeployed)
        {
            ryderPhys.AddForce(transform.right * -uSpeed);
            ryderPhys.AddTorque(transform.forward * uSpeed);
        }
        if (Input.GetKey(KeyCode.D) && !gliderDeployed)
        {
            ryderPhys.AddForce(transform.right * uSpeed);
            ryderPhys.AddTorque(transform.forward * -uSpeed);
        }

        if (Input.GetKey(KeyCode.W) && !gliderDeployed)
        {
            ryderPhys.AddRelativeForce(transform.right * speed);
            //= new Vector3(planeRigid.velocity.x, planeRigid.velocity.y, planeRigid.velocity.z + speed);
        }
        // plane.transform.rotation = new Quaternion(plane.transform.rotation.x - 0.1f, plane.transform.rotation.y, plane.transform.rotation.z, 1);
        if (Input.GetKey("[8]") && gliderDeployed)
        {
            ryderPhys.AddRelativeTorque(transform.up * pitchPower); //right is actually up/down (pitch)
        }
        if (Input.GetKey("[5]") && gliderDeployed)
        {
            ryderPhys.AddRelativeTorque(transform.up * -pitchPower);
        }
        if (Input.GetKey(KeyCode.A) && gliderDeployed)
        {
            //plane.transform.rotation = new Quaternion(plane.transform.rotation.x, plane.transform.rotation.y, plane.transform.rotation.z + rollPower, 1);
            ryderPhys.AddRelativeTorque(transform.forward * -yawPower); //up is actually yaw
        }
        if (Input.GetKey(KeyCode.D) && gliderDeployed)
        {
            //plane.transform.rotation = new Quaternion(plane.transform.rotation.x, plane.transform.rotation.y, plane.transform.rotation.z - rollPower, 1);
            ryderPhys.AddRelativeTorque(transform.forward * yawPower);
        }
        if (Input.GetKey("[6]") && gliderDeployed)
        {
            //plane.transform.rotation = new Quaternion(plane.transform.rotation.x, plane.transform.rotation.y, plane.transform.rotation.z + rollPower, 1);
            ryderPhys.AddRelativeTorque(transform.right * -rollPower); //up is actually yaw
        }
        if (Input.GetKey("[4]") && gliderDeployed)
        {
            //plane.transform.rotation = new Quaternion(plane.transform.rotation.x, plane.transform.rotation.y, plane.transform.rotation.z - rollPower, 1);
            ryderPhys.AddRelativeTorque(transform.right * rollPower);
        }
    }
}
