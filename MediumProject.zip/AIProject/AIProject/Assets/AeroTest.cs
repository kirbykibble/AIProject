﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AeroTest : MonoBehaviour
{

    public GameObject plane;
    private Rigidbody planeRigid;
    public float speed = 1.0f;
    public float pitchPower = 500;
    public float yawPower = 500;
    public float rollPower = 500;


    // Start is called before the first frame update
    void Start()
    {
        planeRigid = plane.GetComponent<Rigidbody>();
    }

    

    // Update is called once per frame
    void FixedUpdate()
    {
        if(Input.GetKey(KeyCode.W))
        {
            planeRigid.AddRelativeForce(transform.forward * speed);
                //= new Vector3(planeRigid.velocity.x, planeRigid.velocity.y, planeRigid.velocity.z + speed);
        }
        // plane.transform.rotation = new Quaternion(plane.transform.rotation.x - 0.1f, plane.transform.rotation.y, plane.transform.rotation.z, 1);
        if (Input.GetKey("[8]"))
        {
            planeRigid.AddRelativeTorque(transform.right * pitchPower); //right is actually up/down (pitch)
        }
        if(Input.GetKey("[5]"))
        {
            planeRigid.AddRelativeTorque(transform.right * -pitchPower); 
        }
        if (Input.GetKey(KeyCode.A))
        {
            //plane.transform.rotation = new Quaternion(plane.transform.rotation.x, plane.transform.rotation.y, plane.transform.rotation.z + rollPower, 1);
            planeRigid.AddRelativeTorque(transform.up * -yawPower); //up is actually yaw
        }
        if (Input.GetKey(KeyCode.D))
        {
            //plane.transform.rotation = new Quaternion(plane.transform.rotation.x, plane.transform.rotation.y, plane.transform.rotation.z - rollPower, 1);
            planeRigid.AddRelativeTorque(transform.up * yawPower); 
        }
        if (Input.GetKey("[6]"))
        {
            //plane.transform.rotation = new Quaternion(plane.transform.rotation.x, plane.transform.rotation.y, plane.transform.rotation.z + rollPower, 1);
            planeRigid.AddRelativeTorque(transform.forward * -rollPower); //up is actually yaw
        }
        if (Input.GetKey("[4]"))
        {
            //plane.transform.rotation = new Quaternion(plane.transform.rotation.x, plane.transform.rotation.y, plane.transform.rotation.z - rollPower, 1);
            planeRigid.AddRelativeTorque(transform.forward * rollPower);
        }
    }
}
