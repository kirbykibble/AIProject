﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cannonScript : MonoBehaviour
{

    public GameObject Ryder;
    public GameObject explosions;
    // Start is called before the first frame update
    void Start()
    {
        Ryder = GameObject.Find("Ryder");
        StartCoroutine(timeout());
    }

    // Update is called once per frame
    void Update()
    {
        if (Vector3.Distance(this.transform.position, Ryder.transform.position) <= 20)
        {
            GameObject newBoom = Instantiate(explosions);
            newBoom.transform.position = this.transform.position;
            Destroy(gameObject);
        }
    }

    IEnumerator timeout()
    {
        yield return new WaitForSeconds(10);
        GameObject newBoom = Instantiate(explosions);
        newBoom.transform.position = this.transform.position;
        Destroy(gameObject);
    }
}
