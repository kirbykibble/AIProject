﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class CameraScript : MonoBehaviour
{
    public GameObject ryder;
    private Vector3 cameraPos;
    private float distance;

    // Start is called before the first frame update
    void Start()
    {
        distance = 2;
    }

    // Update is called once per frame
    void Update()
    {
        cameraPos = new Vector3(ryder.transform.position.x, ryder.transform.position.y + distance, ryder.transform.position.z - (distance * 3));
        transform.position = cameraPos;
    }
}
