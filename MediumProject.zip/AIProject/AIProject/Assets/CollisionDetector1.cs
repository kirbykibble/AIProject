﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollisionDetector1 : MonoBehaviour
{

    public RyderController ryderController;
    public GameObject mainController;


    // Start is called before the first frame update
    void Start()
    {
        ryderController = mainController.GetComponent<RyderController>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnCollisionEnter(Collision collision)
    {
        Debug.Log(collision.gameObject.name);
        if(collision.gameObject.name.Contains("Chunk"))
        {
            ryderController.forceClose();
        }
    }
}
