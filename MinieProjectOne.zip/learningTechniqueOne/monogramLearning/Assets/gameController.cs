﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gameController : MonoBehaviour
{
    public TextMesh playerCoins;
    public TextMesh opponentCoins;
    public TextMesh outText;

    List<bool> playerActions = new List<bool>();
    private int pCoins = 0;
    private int oCoins = 0;

    List<bool> ss = new List<bool>();
    List<bool> tt = new List<bool>();
    List<bool> st = new List<bool>();
    List<bool> ts = new List<bool>();

         /*
        given the last two actions, what is the likelihood that their next action is such ?. 
        ensure that the chance is based entirely off of occurences of s|s or whatever. 

        ngrams should take into account the players last action and current action to determine the ngram
        how to determine ?
        find the list that matches the players last action and current one. 
        take the values within, and calculate the percentage of s and t from the total in the list


        script should........
        for each player input, iterate through the list. (only if list is bigger than 3)
        use the bigram of last input + current input. Check against the likelihoods and choose between s and t as a response from the opponent.

        append the players input to the list of previous inputs.
        build the bigram

        how to build bigram? 
        start at index 1 from the beginning (so one after start)
        see what the bigram consists of (using the previous value and the current value) and add the next value (the next player input) to the bigrams list. */

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.S)) // player splits
        {
            runGame(true);
        }
        if(Input.GetKeyDown(KeyCode.T))
        {
            runGame(false);
        }
    }

    bool makeChoice(List<bool> bigram)
    {
        int sCount = 0;
        int tCount = 0;

        float sLike = 0.0f;
        float tLike = 0.0f;

        bool choice = false;
        for (int i = 0; i < bigram.Count; i++)
        {
            if(bigram[i])
            {
                sCount++;
            }
            else
            {
                tCount++;
            }
        }

        sLike = sCount / bigram.Count;
        tLike = tCount / bigram.Count;

        if(sLike > tLike) //if the likelihood of the player choosing to split is higher than them choosing steal, you should steal
        {
            choice = false;
        }
        if (tLike > sLike) //if the likelihood is for the player to steal, you should steal to prevent your opponent from gaining points.
        {
            choice = false;
        }
        
        return choice;
    }

    void runGame(bool playerAction) //true = split. //false = steal
    {
        bool enemyAction = true; //starts with a split
        string resultText = "";

        if (playerActions.Count >= 3)
        {
            string curChoice = "";
            string curbiGram = "";

            if(playerActions[playerActions.Count - 1])
            {
                curChoice = "s";
            }
            else
            {
                curChoice = "t";
            }

            bool lastChoice = playerActions[playerActions.Count - 2];
            if (lastChoice)
            {
                curbiGram = "s" + curChoice;
            }
            else
            {
                curbiGram = "t" + curChoice;
            }


            //final choice stuff
            if (curbiGram == "ss" && ss.Count > 1)
            {
                enemyAction = makeChoice(ss);
            }
            else if (curbiGram == "tt" && tt.Count > 1)
            {
                print("updating enemy TT");
                enemyAction = makeChoice(tt);
            }
            else if (curbiGram == "st" && st.Count > 1)
            {
                enemyAction = makeChoice(st);
            }
            else if (curbiGram == "ts" && ts.Count > 1)
            {
                enemyAction = makeChoice(ts);
            }

        }


        //if both players split, then they both get 3 coins
        //if one player steals, then they get 6 coins. The other player gets nothing.
        //if both players steal, nobody gets anything
        if (playerAction == enemyAction) 
        {
            if (playerAction)// if they both split
            {
                pCoins += 2;
                oCoins += 2;
                resultText = "both players chose split!";
            }
            if(!playerAction)//if they both steal
            {
                resultText = "both players chose to steal!";
            }
        }
        if (playerAction != enemyAction) //if the choice is different (at least one will be steal)
        {
            if (playerAction) // if player splits
            {
                oCoins += 6;
                resultText = "you chose to split. \n your opponent chose to steal";
            }
            else if (enemyAction) //if opponent splits
            {
                pCoins += 6;
                resultText = "you chose to steal. \n your opponent chose to split";
            }
        }

        playerCoins.text = "Your Coins: " + pCoins;
        opponentCoins.text = "Their Coins: " + oCoins;
        outText.text = resultText;

        playerActions.Add(playerAction);

        if(playerActions.Count >= 3)
        {
            for (int i = 2; i < playerActions.Count; i++)
            {
                string prev = "";
                string cur = "";
                if(playerActions[i-2])
                {
                    prev = "s";
                }
                else
                {
                    prev = "t";
                }
                if(playerActions[i-1])
                {
                    cur = "s";
                }
                else {
                    cur = "t";
                }
                string curbigram = prev + cur;
                print(curbigram);


                if(curbigram == "ss")
                {
                    ss.Add(playerActions[i]);
                }else if(curbigram == "tt")
                {
                    print("updating TT");
                    tt.Add(playerActions[i]);
                }else if(curbigram == "st")
                {
                    st.Add(playerActions[i]);
                }else if(curbigram == "ts")
                {
                    ts.Add(playerActions[i]);
                }
            }
        }
    }
}
